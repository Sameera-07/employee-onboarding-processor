'''from dataclasses import dataclass

@dataclass
class Employee:
    employee_id: str
    name: str
    department: str
    role: str
    joining_date: str
    manager: str '''


from dataclasses import dataclass
from datetime import datetime


REQUIRED_FIELDS = (
    "employee_id",
    "name",
    "department",
    "role",
    "joining_date",
    "manager",
)


@dataclass
class Employee:
    employee_id: str
    name: str
    department: str
    role: str
    joining_date: str
    manager: str

    @classmethod
    def from_dict(cls, row):
        cleaned = {
            key: str(row.get(key) or "").strip()
            for key in REQUIRED_FIELDS
        }

        missing = [
            field for field, value in cleaned.items()
            if not value
        ]

        if missing:
            raise ValueError(
                f"Missing required fields: {', '.join(missing)}"
            )

        try:
            parsed_date = datetime.strptime(
                cleaned["joining_date"], "%Y-%m-%d"
            )
        except ValueError as exc:
            raise ValueError(
                "joining_date must use YYYY-MM-DD format"
            ) from exc

        # Reject dates that are not in canonical ISO format.
        if parsed_date.strftime("%Y-%m-%d") != cleaned["joining_date"]:
            raise ValueError("joining_date must use YYYY-MM-DD format")

        return cls(**cleaned)

    def to_dict(self):
        return {
            field: getattr(self, field)
            for field in REQUIRED_FIELDS
        }
