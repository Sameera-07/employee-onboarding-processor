from pathlib import Path


def render_template(template_path, employee):
    template = Path(template_path).read_text(encoding="utf-8")

    try:
        return template.format(**employee.to_dict())
    except KeyError as exc:
        raise ValueError(
            f"Unknown placeholder in template: {exc}"
        ) from exc