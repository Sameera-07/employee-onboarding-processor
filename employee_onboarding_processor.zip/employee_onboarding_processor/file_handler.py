'''import os
def create_employee_document(employee,template):
    employee_folder=os.path.join("output", employee.employee_id)

    os.makedirs(employee_folder, exist_ok=True)

    document_path=os.path.join(employee_folder, "onboarding.docx")

    employee_data={
        "employee_id": employee.employee_id,
        "name": employee.name,
        "department": employee.department,
        "role": employee.role,
        "joining_date": employee.joining_date,
        "manager": employee.manager
    }

    document_content = template.format(**employee_data)

    with open(document_path, "w", encoding="utf-8") as file:
        file.write(document_content)

    return document_path '''


import csv
import logging
import re
from pathlib import Path

from employee import Employee
from processor import render_template


def setup_logging(output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        filename=output_dir / "onboarding.log",
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        encoding="utf-8",
        force=True,
    )


def read_employees(input_path):
    path = Path(input_path)
    suffix = path.suffix.lower()

    if suffix == ".csv":
        with path.open("r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)

            if not reader.fieldnames:
                raise ValueError("CSV file has no header row")

            return list(reader)

    if suffix == ".xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise RuntimeError(
                "Install Excel support: pip install openpyxl"
            ) from exc

        workbook = load_workbook(
            path, read_only=True, data_only=True
        )

        try:
            sheet = workbook.active
            rows = sheet.iter_rows(values_only=True)
            headers = next(rows, None)

            if not headers:
                raise ValueError("Excel file has no header row")

            headers = [
                str(value).strip() if value is not None else ""
                for value in headers
            ]

            return [
                dict(zip(headers, row))
                for row in rows
                if any(value is not None for value in row)
            ]
        finally:
            workbook.close()

    raise ValueError("Input must be a .csv or .xlsx file")


def safe_folder_name(value):
    # Avoid path traversal and unsafe filename characters.
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", value).strip("_")
    if not cleaned or cleaned in {".", ".."}:
        raise ValueError("Employee ID is not a safe folder name")
    return cleaned


def process_employees(input_path, template_path, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_logging(output_dir)

    summary = {
        "total": 0,
        "success": 0,
        "failed": 0,
        "skipped": 0,
        "errors": [],
    }
    seen_ids = set()

    try:
        rows = read_employees(input_path)
    except Exception:
        logging.exception("Could not read input file")
        raise

    summary["total"] = len(rows)

    for row_number, row in enumerate(rows, start=2):
        employee_id = str(row.get("employee_id") or "").strip()

        try:
            employee = Employee.from_dict(row)

            if employee.employee_id in seen_ids:
                summary["skipped"] += 1
                message = (
                    f"Row {row_number}: duplicate employee ID "
                    f"{employee.employee_id}"
                )
                summary["errors"].append(message)
                logging.warning(message)
                continue

            seen_ids.add(employee.employee_id)

            folder_name = safe_folder_name(employee.employee_id)
            employee_dir = output_dir / (
                f"{folder_name}_{safe_folder_name(employee.name)}"
            )

            # Do not overwrite a previously generated employee folder.
            if employee_dir.exists():
                summary["skipped"] += 1
                message = (
                    f"Row {row_number}: output folder already exists "
                    f"for {employee.employee_id}"
                )
                summary["errors"].append(message)
                logging.warning(message)
                continue

            document = render_template(template_path, employee)

            employee_dir.mkdir(parents=True)
            try:
                (employee_dir / "onboarding.txt").write_text(
                    document, encoding="utf-8"
                )
            except OSError:
                # Remove a partially generated folder on failure.
                import shutil
                shutil.rmtree(employee_dir, ignore_errors=True)
                raise

            summary["success"] += 1
            logging.info(
                "Generated onboarding document for %s",
                employee.employee_id,
            )

        except (ValueError, OSError, KeyError) as exc:
            summary["failed"] += 1
            message = f"Row {row_number}: {exc}"
            summary["errors"].append(message)
            logging.exception(message)

    report_path = output_dir / "processing_summary.txt"
    report_lines = [
        "EMPLOYEE ONBOARDING PROCESSING SUMMARY",
        "=" * 40,
        f"Total records: {summary['total']}",
        f"Successfully processed: {summary['success']}",
        f"Failed records: {summary['failed']}",
        f"Skipped records: {summary['skipped']}",
        "",
        "ERRORS / SKIPPED RECORDS",
        "-" * 40,
    ]
    report_lines.extend(summary["errors"] or ["None"])

    report_path.write_text(
        "\n".join(report_lines) + "\n", encoding="utf-8"
    )

    logging.info(
        "Completed: total=%d success=%d failed=%d skipped=%d",
        summary["total"],
        summary["success"],
        summary["failed"],
        summary["skipped"],
    )

    return summary
