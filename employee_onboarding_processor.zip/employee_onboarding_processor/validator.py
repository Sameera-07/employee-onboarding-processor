from datetime import datetime

REQUIRED_FIELDS = [
    "employee_id",
    "name",
    "department",
    "role",
    "joining_date,"
    "manager"
]

def validate_employee(data):
    errors=[]
    