
from pathlib import Path

from file_handler import process_employees


BASE_DIR = Path(__file__).resolve().parent

INPUT_FILE = BASE_DIR / "input" / "employees.csv"
TEMPLATE_FILE = BASE_DIR / "templates" / "onboarding_template.txt"
OUTPUT_DIR = BASE_DIR / "output"


def main():
    try:
        summary = process_employees(
            INPUT_FILE,
            TEMPLATE_FILE,
            OUTPUT_DIR,
        )

        print("\nOnboarding processing completed.")
        print(f"Total records: {summary['total']}")
        print(f"Successful: {summary['success']}")
        print(f"Failed: {summary['failed']}")
        print(f"Skipped: {summary['skipped']}")
        print(f"Output folder: {OUTPUT_DIR}")

    except (OSError, ValueError, RuntimeError) as exc:
        print(f"Processing could not be completed: {exc}")
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
