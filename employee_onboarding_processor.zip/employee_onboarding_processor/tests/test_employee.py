
import unittest
import sys
from pathlib import Path

sys.path.insert(
    0,
    str(Path(__file__).resolve().parent.parent)
)

from employee import Employee


class TestEmployee(unittest.TestCase):

    def setUp(self):
        self.valid_record = {
            "employee_id": "EMP001",
            "name": "John Doe",
            "department": "IT",
            "role": "Developer",
            "joining_date": "2026-11-02",
            "manager": "Alice Brown",
        }

    def test_valid_employee(self):
        employee = Employee.from_dict(self.valid_record)
        self.assertEqual(employee.employee_id, "EMP001")
        self.assertEqual(employee.name, "John Doe")

    def test_missing_name(self):
        record = self.valid_record.copy()
        record["name"] = ""

        with self.assertRaisesRegex(ValueError, "Missing required"):
            Employee.from_dict(record)

    def test_invalid_date(self):
        record = self.valid_record.copy()
        record["joining_date"] = "02-11-2026"

        with self.assertRaisesRegex(ValueError, "YYYY-MM-DD"):
            Employee.from_dict(record)

    def test_invalid_calendar_date(self):
        record = self.valid_record.copy()
        record["joining_date"] = "2026-02-30"

        with self.assertRaises(ValueError):
            Employee.from_dict(record)

    def test_to_dict(self):
        employee = Employee.from_dict(self.valid_record)
        self.assertEqual(employee.to_dict(), self.valid_record)


if __name__ == "__main__":
    unittest.main()
